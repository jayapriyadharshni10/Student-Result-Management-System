CREATE DATABASE student_results;
USE student_results;

CREATE TABLE students (
  student_id VARCHAR(10) PRIMARY KEY,
  name VARCHAR(100),
  password VARCHAR(100),
  math INT,
  science INT,
  english INT
);

INSERT INTO students VALUES ('S001', 'Anjali', '1234', 78, 88, 84);
INSERT INTO students VALUES ('S002', 'Rahul', 'abcd', 92, 76, 81);